from pygame import *
from random import *
from moviepy import editor
score =[0, 0]
framesStartL = 0
f2 = font.SysFont('arial.ttf', 50)
framesStartR = 0
w = 1000
h= 600
start = False
text5 = f2.render("1", 100, (0, 20, 0))
text2 = f2.render("2", 100, (0, 20, 0))
text3 = f2.render("3", 100, (0, 20, 0))
text4 = f2.render("4", 100, (0, 20, 0))
frames = []

ball_image = "Ball.png"
ball2_image = "Ball2.png"
ball3_image = "Ball3.png"
ball4_image = "Ball4.png"
Rock_image = "plane.png"
ball1im = image.load(ball_image)
ball1im = transform.scale(ball1im, (100, 100))
ball2im = image.load(ball2_image)
ball2im = transform.scale(ball2im, (100, 100))
ball3im = image.load(ball3_image)
ball3im = transform.scale(ball3im, (100, 100))
ball4im = image.load(ball4_image)
ball4im = transform.scale(ball4im, (100, 100))
clip = editor.VideoFileClip("animation.gif")
window = display.set_mode((w,h), SRCALPHA)
background = transform.scale(image.load("BG.jpg"), (w,h))
direction = choice([True, False])
frame_index = 0
mixer.init()
puk = mixer.Sound("puk.ogg") 
tudun = mixer.Sound("tudun.ogg")
tudun.play()
for frame in clip.iter_frames():
    frame = image.frombuffer(frame.tobytes(), clip.size, 'RGB')
    frame= transform.scale(frame, (500, 200))
    colorkey = (255, 255, 255)
    frame.set_colorkey(colorkey) 
    frames.append(frame) 
    

if direction:
    speedx = 10
else:
    speedx = -10 
speedy = 10





class Player(sprite.Sprite):
    def __init__(self, x, y, player_image, speed, width, height ):
        super().__init__()
        self.image = transform.scale(image.load(player_image),(width,height))
        self.speed = speed
        self.rect = self.image.get_rect() 
        self.rect.x = x
        self.rect.y = y
    def reset(self):
        window.blit(self.image, (self.rect.x, self.rect.y))
class Hero(Player):
    def update(self):
        keys = key.get_pressed()
        global start
        if keys[K_UP] and self.rect.y>0 and start:
            self.rect.y -= self.speed
        if keys[K_DOWN] and self.rect.y<h-180 and start :
            self.rect.y +=self.speed
class Hero2(Player):
    def update(self):
        keys = key.get_pressed()
        global start
        if keys[K_w] and self.rect.y>0 and start:
            self.rect.y -= self.speed
        if keys[K_s] and self.rect.y<h-180 and start :
            self.rect.y +=self.speed
class Ball(Player):
    def update(self):
        global start
        
        global speedx
        global speedy

        global direction
        global framesStartL
        global framesStartR

        if start:
            self.rect.x +=speedx
            self.rect.y +=speedy
            if self.rect.y >500:
                speedy = speedy*-1
            if self.rect.y<0:
                speedy = speedy*-1
            if self.rect.x > 1000:
                self.rect.x = 500
                speedx = 10
                start = False
                direction = choice([True, False])
                framesStartR = 0
                framesStartL = 0
                if direction:
                    speedx = 10
                else:
                    speedx = -10 
                speedy = 10
                self.rect.y = 250
                hero1.rect.y = 250
                hero2.rect.y = 250
                tudun.play()
                score[1]+=1
            if self.rect.x < 0:
                self.rect.x = 500
                speedx = 10
                start = False
                
                direction = choice([True, False])
                if direction:
                    speedx = 10
                else:
                    speedx = -10 
                speedy = 10
                self.rect.y = 250
                framesStartR = 0
                framesStartL = 0
                hero1.rect.y = 250
                hero2.rect.y = 250
                score[0]+=1
                tudun.play()



ball = Ball(500, 250, ball_image, 5 , 100 , 100)
hero1 = Hero(900, 0, Rock_image, 20 , 50 , 200)
hero2 = Hero2(100, 0, Rock_image, 20 , 50 , 200)



clock = time.Clock()
FPS = 44
game = True
finish = False
while game:
    for e in event.get():
        if e.type == QUIT :
            game = False
    if finish != True:
        if sprite.collide_rect(ball, hero1) and direction:
            speedx = speedx*-1
            speedx = speedx + speedx/30
            direction = False
            hero1.image = transform.scale(image.load(Rock_image), (40, 240))
            puk.play()
        if sprite.collide_rect(ball, hero2) and direction == False:
            speedx = speedx*-1
            speedx = speedx + speedx/30
            direction = True
            hero2.image = transform.scale(image.load(Rock_image), (40, 240))
            puk.play()
        window.blit(background,(0,0))
        hero1.reset()
        hero1.update()
        hero2.reset()
        hero2.update()
        if ball.rect.x < 800: 
                hero1.image = transform.scale(image.load(Rock_image), (50, 200))
        if ball.rect.x > 150: 
                hero2.image = transform.scale(image.load(Rock_image), (50, 200))
        if start:
            ball.reset()
            ball.update()
        if start == False and direction == True:
            
            window.blit(frames[frame_index], (250, 150))
            frame_index = (frame_index + 1) % len(frames)
            framesStartR += 1
            if framesStartR == 110:
                clock.tick(1)
                start = True
                framesStartR = 0
                frame_index = 0
        text1 = f2.render("Ваш рахунок - "+str(score[1])+"Проти" + str(score[0]), 100, (0, 20, 0))
        window.blit(text1, (300, 0))
        if start == False and direction == False:
            
            window.blit(frames[frame_index], (250, 150))
            frame_index = (frame_index + 1) % len(frames)
            framesStartL += 1

            if framesStartL == 126:
                clock.tick(1)
                start = True
                framesStartL = 0
                frame_index = 0
        if start != True:
            window.blit(ball2im, (250, 450))
            
            window.blit(text5, (250, 550))
            #self.image = transform.scale(image.load(player_image),(width,height))
            window.blit(ball1im, (350, 450))
            window.blit(text2, (350, 550))
            window.blit(ball3im, (450, 450))
            window.blit(text3, (450, 550))
            window.blit(ball4im, (550, 450))
            window.blit(text4, (550, 550))
        keys = key.get_pressed()
        if keys[K_1] and start == False:
            print("fdsdf")
            ball.image = ball2im
        if keys[K_2] and start == False:
            ball.image = ball1im
            print("fdsdf")
        if keys[K_3] and start == False:
            ball.image = ball3im
            print("fdsdf")
        if keys[K_4] and start == False:
            ball.image = ball4im
            print("fdsdf")
        print(start)
    display.update()
    clock.tick(FPS)